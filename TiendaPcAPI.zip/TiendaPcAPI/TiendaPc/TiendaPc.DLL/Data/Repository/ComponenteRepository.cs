﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TiendaPc.DLL.Data.Repository.Interfaces;

namespace TiendaPc.DLL.Data.Repository
{
    public class ComponenteRepository : IComponenteRepository
    {


    }
}
